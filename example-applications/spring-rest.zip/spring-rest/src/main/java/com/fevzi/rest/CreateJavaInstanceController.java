package com.fevzi.rest;

import org.springframework.extra.web.handler.annotation.ExternalMethodExceptionHandlers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fevzi.rest.exception.handler.SystemExceptionsHandler;

@Controller
@RequestMapping("/createInstance")
@ExternalMethodExceptionHandlers({ SystemExceptionsHandler.class })
public class CreateJavaInstanceController {

	@ResponseBody
	@RequestMapping(method = RequestMethod.GET)
	public Object raiseException(
			@RequestParam("className") final String className) throws Exception {
		final Class<?> clazz = Class.forName(className);
		if (Exception.class.isAssignableFrom(clazz)) {
			throw (Exception) clazz.newInstance();
		} else {
			return clazz.newInstance();
		}
	}

}
