package com.fevzi.rest.exception.handler;

import org.springframework.extra.web.handler.ExternalMethodExceptionHandler;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Component
public class SystemExceptionsHandler implements ExternalMethodExceptionHandler {

	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	@ExceptionHandler({ ClassNotFoundException.class })
	public String handleClassNotFoundException(final Exception excp) {
		return excp.getClass().getName();
	}

	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	@ExceptionHandler({ RuntimeException.class })
	public String handleRuntimeException(final Exception excp) {
		return excp.getClass().getName();
	}

	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ResponseBody
	@ExceptionHandler({ MissingServletRequestParameterException.class })
	public String handleMissingServletRequestParameterException(
			final Exception excp) {
		return excp.getClass().getName();
	}

}
